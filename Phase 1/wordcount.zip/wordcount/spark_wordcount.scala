val hashtagCounts = sc.textFile("hashtags.txt").map(line => (line, 1)).reduceByKey(_ + _)

val urlCounts = sc.textFile("urls.txt").map(line => (line, 1)).reduceByKey(_ + _)

// Print results
println("Hashtag Counts:")
hashtagCounts.take(10).foreach(println)

println("\nURL Counts:")
urlCounts.take(10).foreach(println)

// Save output to file (optional)
hashtagCounts.saveAsTextFile("spark_output_hashtags")
urlCounts.saveAsTextFile("spark_output_urls")