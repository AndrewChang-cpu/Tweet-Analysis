# Tweet-Analysis: Phase 1

## Goal
- Use the tweets datasets.
- Extract all the hashtags and URLs in the tweets – write your own code in any language.
- Run the WordCount example in Apache Hadoop and Apache Spark on the extracted hashtags/URLs and collect the output and log files from Hadoop.
- Add a README file.

## Steps

### 1. Extract Hashtags and URLs
Write a script in any language to extract hashtags and URLs from the tweets dataset provided on Canvas. Save the extracted hashtags to `hashtags.txt` and the URLs to `urls.txt`.

### 2. Run Hadoop WordCount
Use the Hadoop WordCount example to process the extracted hashtags and URLs.

```bash
hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-2.8.1.jar wordcount /phase1/hashtags.txt /phase1/output/hashtags_output
hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-2.8.1.jar wordcount /phase1/urls.txt /phase1/output/urls_output
```

### 3. Run Spark WordCount
Use the Spark WordCount example to process the extracted hashtags and URLs.

```scala
val hashtagCounts = sc.textFile("hashtags.txt").map(line => (line, 1)).reduceByKey(_ + _)
val urlCounts = sc.textFile("urls.txt").map(line => (line, 1)).reduceByKey(_ + _)

// Print results
println("Hashtag Counts:")
hashtagCounts.take(10).foreach(println)

println("\nURL Counts:")
urlCounts.take(10).foreach(println)

// Save output to file (optional)
hashtagCounts.saveAsTextFile("spark_output_hashtags")
urlCounts.saveAsTextFile("spark_output_urls")
```

### 4. Collect Output and Log Files
After running the WordCount example, collect the output and log files from Hadoop and Spark for analysis.

## Files
- `hadoop_wordcount.sh`: Script to run the Hadoop WordCount example on the extracted hashtags and URLs.
- `spark_wordcount.scala`: Script to run the Spark WordCount example on the extracted hashtags and URLs.
- `README.md`: This README file.

## Output
This is included in this folder but renamed for convenience.
- `hashtags_output`: Directory containing the WordCount output for hashtags from Hadoop.
- `urls_output`: Directory containing the WordCount output for URLs from Hadoop.
- `spark_output_hashtags`: Directory containing the WordCount output for hashtags from Spark.
- `spark_output_urls`: Directory containing the WordCount output for URLs from Spark.

## Notes
- Ensure Hadoop and Spark are properly configured and running before executing the scripts.
- Review the Hadoop and Spark logs for any errors or issues during execution.
